package com.example.fodd_app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fodd_app.entities.user;

public interface UserRepo extends JpaRepository<user, Integer>{

}
