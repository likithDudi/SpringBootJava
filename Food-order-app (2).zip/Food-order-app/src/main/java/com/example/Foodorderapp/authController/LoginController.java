package com.example.Foodorderapp.authController;

import com.example.Foodorderapp.authExceptions.AuthorizationExceptions;
import com.example.Foodorderapp.authModels.Login;
import com.example.Foodorderapp.authServices.LoginServiceImpl;
import org.springframework.web.bind.annotation.*;


@RestController
public class LoginController {

    private LoginServiceImpl loginService;

    @PostMapping("/login")
    public String loginHandler(@RequestBody Login loginData) throws AuthorizationExceptions {
        return loginService.LogIn(loginData);
    }

    @PatchMapping("/logout")
    public String logOutFromAccount(@RequestParam String key) throws AuthorizationExceptions
    {
        return loginService.LogOut(key);
    }
}
