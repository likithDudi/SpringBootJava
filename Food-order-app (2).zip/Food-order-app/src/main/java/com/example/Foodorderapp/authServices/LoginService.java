package com.example.Foodorderapp.authServices;

import com.example.Foodorderapp.authExceptions.AuthorizationExceptions;
import com.example.Foodorderapp.authModels.Login;

public interface LoginService {

    public String LogIn(Login login) throws AuthorizationExceptions;

    public String LogOut(String key) throws AuthorizationExceptions;
}
