package com.example.Foodorderapp.authServices;

import com.example.Foodorderapp.authExceptions.AuthorizationExceptions;
import com.example.Foodorderapp.authModels.Signup;
import com.example.Foodorderapp.authRepositories.SignupDAO;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SignupServiceImpl implements SignupService{

    private SignupDAO signupDAO;
    private UserService userLogin;

    @Override
    public Signup newSignUp(Signup signUp) throws AuthorizationExceptions {
        Optional<Signup> opt = signupDAO.findByUserName(signUp.getUserName());
        if(opt.isPresent())
        {
            throw new AuthorizationExceptions("User Already Exists..!!");
        }

        return signupDAO.save(signUp);
    }

    @Override
    public Signup updateSignUp(Signup signUp, String key) throws AuthorizationExceptions {

        Signup signUpDetails = userLogin.getSignUpDetails(key);

        if(signUpDetails == null)
        {
            throw new AuthorizationExceptions("User not LoggedIn...!! Try To Login first..");
        }

        if(signUpDetails.getUserId() == signUp.getUserId())
        {
            signupDAO.save(signUp);
            return signUp;
        }
        else
            throw new AuthorizationExceptions("UserId not found..!!");
    }

}
