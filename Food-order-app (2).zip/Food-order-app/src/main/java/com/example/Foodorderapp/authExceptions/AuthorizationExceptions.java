package com.example.Foodorderapp.authExceptions;

public class AuthorizationExceptions extends Exception {

    public AuthorizationExceptions() {
        // TODO Auto-generated constructor stub
    }


    public AuthorizationExceptions(String message) {
        super(message);

    }
}
