package com.example.Foodorderapp.exceptions;

public class CartException extends Exception{

    public CartException(){

    }
    public CartException(String message){
        super(message);
    }
}
