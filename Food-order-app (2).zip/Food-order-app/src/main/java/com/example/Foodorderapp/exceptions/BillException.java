package com.example.Foodorderapp.exceptions;

public class BillException extends Exception{

    public BillException(){

    }
    public BillException(String message){
        super(message);
    }
}
