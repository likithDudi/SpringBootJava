package com.example.Foodorderapp.authServices;

import com.example.Foodorderapp.authExceptions.AuthorizationExceptions;
import com.example.Foodorderapp.authModels.Signup;
import com.example.Foodorderapp.authModels.User;
import com.example.Foodorderapp.authRepositories.SignupDAO;
import com.example.Foodorderapp.authRepositories.UserDAO;

import java.util.Optional;

public class UserServiceImpl implements UserService{


    private UserDAO userDAO;
    private SignupDAO signupDAO;


    @Override
    public User getUserSession(String key) throws AuthorizationExceptions {
        Optional<User> currentUser = userDAO.findByUUID(key);
        if(!currentUser.isPresent())
        {
            throw new AuthorizationExceptions("Not Authorized..!!");
        }
        return currentUser.get();
    }

    @Override
    public Integer getUserSessionId(String key) throws AuthorizationExceptions {
        Optional<User> currentUser = userDAO.findByUUID(key);
        if(!currentUser.isPresent())
        {
            throw new AuthorizationExceptions("Not Authorized..!!");
        }
        return currentUser.get().getId();
    }

    @Override
    public Signup getSignUpDetails(String key) throws AuthorizationExceptions {
        Optional<User> currentUser = userDAO.findByUUID(key);
        if(!currentUser.isPresent())
        {
            return null;
        }
        Integer SignUpUserId = currentUser.get().getUserId();
        System.out.println(SignUpUserId );

        return (signupDAO.findById(SignUpUserId)).get();
    }

}
