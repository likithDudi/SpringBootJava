package com.example.Foodorderapp.exceptions;

public class CategoryException extends Exception {
    public CategoryException(){

    }

    public CategoryException(String message){
        super(message);

    }
}
