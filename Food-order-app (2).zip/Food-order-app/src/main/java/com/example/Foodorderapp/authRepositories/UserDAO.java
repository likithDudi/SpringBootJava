package com.example.Foodorderapp.authRepositories;

import com.example.Foodorderapp.authModels.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository

public interface UserDAO extends CrudRepository<User,Integer> {

    public Optional<User> findByUserId(Integer userId);

    public Optional<User> findByUUID(String uuid);
}
