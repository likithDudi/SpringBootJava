package com.example.Foodorderapp.authRepositories;

import com.example.Foodorderapp.authModels.Login;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
;

@Repository

public interface LoginDAO extends CrudRepository<Login,Integer> {


}
