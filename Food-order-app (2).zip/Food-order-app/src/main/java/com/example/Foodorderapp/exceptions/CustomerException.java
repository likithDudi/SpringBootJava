package com.example.Foodorderapp.exceptions;

public class CustomerException extends Exception {

    public CustomerException(){

    }
    public CustomerException(String message){
        super(message);

    }
}
