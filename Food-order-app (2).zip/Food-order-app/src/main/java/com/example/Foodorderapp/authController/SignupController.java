package com.example.Foodorderapp.authController;


import com.example.Foodorderapp.authExceptions.AuthorizationExceptions;
import com.example.Foodorderapp.authModels.Signup;
import com.example.Foodorderapp.authServices.SignupService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SignupController {


    private SignupService signUpService;

    @PostMapping("/signUp")
    public ResponseEntity<Signup> createNewSignUpHandler(@RequestBody Signup newSignUp) throws AuthorizationExceptions {

        Signup newSignedUp =signUpService.newSignUp(newSignUp);
        return new ResponseEntity<Signup>(newSignedUp, HttpStatus.CREATED);

    }


    @PutMapping("/updateSignUp")
    public ResponseEntity<Signup> updateSignUpDetailsHandler(@RequestBody Signup signUp, @RequestParam String key) throws AuthorizationExceptions
    {
        Signup newUpdatedSignUp = signUpService.updateSignUp(signUp,key);

        return new ResponseEntity<Signup>(newUpdatedSignUp,HttpStatus.ACCEPTED);


    }
}



