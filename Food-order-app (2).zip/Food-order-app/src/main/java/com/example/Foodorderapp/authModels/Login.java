package com.example.Foodorderapp.authModels;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.jetbrains.annotations.NotNull;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Login {

    @Id
    @NotNull
    private Integer userId;

    private String userName;
    private String password;
}
