package com.example.Foodorderapp.authServices;

import com.example.Foodorderapp.authExceptions.AuthorizationExceptions;
import com.example.Foodorderapp.authModels.Signup;

public interface SignupService {

    public Signup newSignUp(Signup signUp) throws AuthorizationExceptions;
    public Signup updateSignUp(Signup signUp, String key) throws AuthorizationExceptions;
}
