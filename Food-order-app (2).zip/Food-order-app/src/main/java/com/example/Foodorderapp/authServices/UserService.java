package com.example.Foodorderapp.authServices;

import com.example.Foodorderapp.authExceptions.AuthorizationExceptions;
import com.example.Foodorderapp.authModels.Signup;
import com.example.Foodorderapp.authModels.User;

public interface UserService {

    public User getUserSession(String key) throws AuthorizationExceptions;

    public Integer getUserSessionId(String key) throws AuthorizationExceptions;

    public Signup getSignUpDetails(String key) throws AuthorizationExceptions;
}
