package com.example.Foodorderapp.authModels;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity

public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(unique =  true)
    private Integer userId;
    private String UUID;
    private LocalDateTime timeStamp;

    public User(Integer userId, String key, LocalDateTime now) {

    }

    public void UserSession(Integer userId, String uuid, LocalDateTime localDateTime) {
        this.userId = userId;
        this.UUID = uuid;
        this.timeStamp = localDateTime;
    }
}
