package com.example.Foodorderapp.authRepositories;

import com.example.Foodorderapp.authModels.Signup;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository

public interface SignupDAO extends CrudRepository<Signup , Integer> {
    public Optional<Signup> findByUserName(String userName);
}
