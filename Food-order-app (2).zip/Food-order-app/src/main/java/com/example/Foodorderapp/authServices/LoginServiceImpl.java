package com.example.Foodorderapp.authServices;


import com.example.Foodorderapp.authExceptions.AuthorizationExceptions;
import com.example.Foodorderapp.authModels.Login;
import com.example.Foodorderapp.authModels.Signup;
import com.example.Foodorderapp.authModels.User;
import com.example.Foodorderapp.authRepositories.LoginDAO;
import com.example.Foodorderapp.authRepositories.SignupDAO;
import com.example.Foodorderapp.authRepositories.UserDAO;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class LoginServiceImpl implements LoginService{


    private SignupDAO signupDAO;
    private UserDAO userDAO;
    private UserService userLoginService;

    private LoginDAO loginDataDAO;


    @Override
    public String LogIn(Login loginData) throws AuthorizationExceptions {

        Optional<Signup> optionalSignup = this.signupDAO.findById(loginData.getUserId());
        if (!optionalSignup.isPresent()){
            throw new AuthorizationExceptions("Invalid Login UserId");
        }
        Signup newSignUp = optionalSignup.get();

        Integer newSignUpId = newSignUp.getUserId();
        Optional<User> currentUserOptional = userDAO.findByUserId(newSignUpId);

        if(currentUserOptional.isPresent()) {
            throw new AuthorizationExceptions("User Already LoggedIn with this UserId");
        }

        if((newSignUp.getUserId() == loginData.getUserId()) && (newSignUp.getPassword().equals(loginData.getPassword())))
        {
            String key = RandomString.getRandomString();

            User currentUserSession = new User(newSignUp.getUserId(),key, LocalDateTime.now());
            userDAO.save(currentUserSession);
            loginDataDAO.save(loginData);

            return currentUserSession.toString();

        }
        else
            throw new AuthorizationExceptions("Invalid UserName or Password..");

    }

    @Override
    public String LogOut(String key) throws AuthorizationExceptions {
        return null;
    }
}
