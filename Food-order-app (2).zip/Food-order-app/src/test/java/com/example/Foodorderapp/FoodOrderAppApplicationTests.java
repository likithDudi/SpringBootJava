package com.example.Foodorderapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodOrderAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
